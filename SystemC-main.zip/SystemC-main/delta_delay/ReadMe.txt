Example Ch2 Sl. 26
