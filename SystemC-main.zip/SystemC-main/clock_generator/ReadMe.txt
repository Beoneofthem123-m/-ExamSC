Example Ch2 Sl 49
