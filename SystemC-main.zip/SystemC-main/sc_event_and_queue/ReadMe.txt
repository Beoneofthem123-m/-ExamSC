Example of CH 2 Sl 46
