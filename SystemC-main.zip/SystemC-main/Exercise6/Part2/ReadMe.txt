Interconnet implemented, 2 cpu 1 interconnet and 2 memories
