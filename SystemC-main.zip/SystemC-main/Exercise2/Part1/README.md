# Exercise 2 SystemC and Virtual Prototyping (SCVP)
Dr.-Ing. Matthias Jung
University of Kaiserslautern

This is the template for the SystemC XOR task of the SCVP course.
Please see the lab instructions for further Information.
