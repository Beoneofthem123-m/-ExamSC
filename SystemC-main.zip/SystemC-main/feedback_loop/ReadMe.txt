Example Ch 2, Sl 32
Infinity loop 
