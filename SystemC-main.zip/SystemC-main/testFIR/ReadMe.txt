Example of RS lacth using  Threads
