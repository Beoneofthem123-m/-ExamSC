Example of FIFO using libraries
