Example Ch 2 Sl 59
